
mongodb_address = "172.17.0.3:27017"
searx_address = "http://172.17.0.4:8888"